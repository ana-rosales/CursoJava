## Ejemplos  JPA

En este repositorio encontrarán dos ejemplos iguales pero abordando las clases de persistencia de diferentes formas.

### Ejemplo 1

El ejemplo 1 usa una clase DAO genérica que luego es heredada por las demás clases DAO de las entidades. **Esta es la mejor práctica.**

### Ejemplo 2

El ejemplo 2, por otro lado, trabaja sin la herencia, de la misma forma que se ve en los videos del tema.

### Nota

Es muy importante para ambos casos crear una base de datos llamada perros. Recuerda también que está colocada la contraseña y usuario por default que son 'root'. 
Si has cambiado alguno de estos valores debes cambiarlos en la unidad de persistencia.
