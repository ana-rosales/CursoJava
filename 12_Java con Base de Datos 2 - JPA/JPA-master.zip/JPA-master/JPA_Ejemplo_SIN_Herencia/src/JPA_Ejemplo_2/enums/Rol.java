// esta clase enum se utilizará para asignarle un rol
// a la entidad Persona. Este rol puede ser: ADMIN o USER.
package JPA_Ejemplo_2.enums;

public enum Rol { ADMIN, USER; }
